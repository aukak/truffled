MrChromebox's ChromeOS Firmware Utility script modified for a shim environment
None of these files are owned by Mercury Workshop
Based on commit https://github.com/MrChromebox/scripts/commit/342fdbbff3d088989799d3749c7ce9759ff2da0a
