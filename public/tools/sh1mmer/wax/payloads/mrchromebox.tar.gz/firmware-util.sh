#!/bin/bash
#
# This script offers provides the ability to update the
# Legacy Boot payload, set boot options, and install
# a custom coreboot firmware for supported
# ChromeOS devices
#
# Created by Mr.Chromebox <mrchromebox@gmail.com>
#
# May be freely distributed and modified as needed,
# as long as proper attribution is given.
#

#path to directory where script is saved
script_dir=$(dirname "$(readlink -f "$0")")

#where the stuff is
script_url="https://raw.githubusercontent.com/MrChromebox/scripts/master/"

#ensure output of system tools in en-us for parsing
export LC_ALL=C

# clear screen / show banner
printf "\ec"
echo -e "\nMrChromebox Firmware Utility Script starting up"

export CURL="curl"

source "$script_dir"/sources.sh
source "$script_dir"/firmware.sh
source "$script_dir"/functions.sh

#set working dir
cd /tmp

#do setup stuff
prelim_setup || exit 1

menu_fwupdate
