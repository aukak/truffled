#!/bin/bash
#

export offline_source="$script_dir"/offline

#define these here for easy updating
export script_date="[2024-04-16]"

#where the stuff is
export util_source="$offline_source"/
export rwlegacy_source="$offline_source"/
export bootstub_source="$offline_source"/
export fullrom_source="$offline_source"/
export shellball_source="$offline_source"/
export cbfs_source="$offline_source"/
export other_source="$offline_source"/

#RW_LEGACY payloads
export seabios_link="seabios-link-mrchromebox_20180912.bin"
export seabios_hswbdw_box="seabios-hswbdw_box-mrchromebox_20180912.bin"
export seabios_hswbdw_book="seabios-hswbdw_book-mrchromebox_20180912.bin"
export seabios_baytrail="seabios-byt-mrchromebox_20180912.bin"
export seabios_braswell="seabios-bsw-mrchromebox_20180912.bin"
export seabios_skylake="seabios-skl-mrchromebox_20180912.bin"
export seabios_apl="seabios-apl-mrchromebox_20180912.bin"
export seabios_kbl="seabios-kbl-mrchromebox_20200223.bin"
export seabios_kbl_18="seabios-kbl_18-mrchromebox_20200223.bin"
export rwl_altfw_stoney="rwl_altfw_stoney-mrchromebox_20200107.bin"
export rwl_altfw_whl="rwl_altfw_whl-mrchromebox_20201017.bin"
export rwl_altfw_cml="rwl_altfw_cml-mrchromebox_20210415.bin"
export rwl_altfw_drallion="rwl_altfw_drallion-mrchromebox_20221019.bin"
export rwl_altfw_glk="rwl_altfw_glk-mrchromebox_20230110.bin"
export rwl_altfw_jsl="rwl_altfw_jsl-mrchromebox_20211115.bin"
export rwl_altfw_pco="rwl_altfw_pco-mrchromebox_20240412.bin"
export rwl_altfw_tgl="rwl_altfw_tgl-mrchromebox_20210827.bin"
export rwl_altfw_adl="rwl_altfw_adl-mrchromebox_20240417.bin"
export rwl_altfw_adl_n="rwl_altfw_adl_n-mrchromebox_20240417.bin"
export rwl_altfw_mdn="rwl_altfw_mdn-mrchromebox_20230727.bin"
export rwl_altfw_czn="rwl_altfw_czn-mrchromebox_20230907.bin"
